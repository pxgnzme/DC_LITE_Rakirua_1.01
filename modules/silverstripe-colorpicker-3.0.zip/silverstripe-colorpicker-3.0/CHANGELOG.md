# silverstripe-colorpicker

## 1.0

Initial import from http://bummzack.ch/colorpicker/
